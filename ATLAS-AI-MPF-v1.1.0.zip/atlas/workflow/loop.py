"""The agent workflow loop.

Orchestrates the Observe -> Understand -> Reason -> Plan -> Execute -> Verify
loop for a stream of source records, target-agnostic (desktop window or web
page). It drives every stage explicitly, emits events and state transitions,
and refuses to continue past a record whose actions failed verification.

    while records remain:
        observe    -> target.observe()                       (VLM scene)
        understand -> SourceReader  -> SourceRecord
                     discover_fields -> editable fields
        reason     -> SemanticMapper -> MappingResult
        plan       -> ActionPlanner  -> FillPlan
        execute    -> ActionExecutor  -> verified results
        verify     -> every value-producing action verified (executor)
        next       -> poll until the source record changes, or timeout
"""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from atlas.act.executor import ActionExecutor
from atlas.act.models import ActionResult, ActionType
from atlas.core.events import EventType, get_event_bus
from atlas.core.logging import logger
from atlas.core.metrics import Timer
from atlas.core.states import AgentState, StateMachine
from atlas.mapping.mapper import MappingResult, SemanticMapper
from atlas.observe.screen_state import build_screen_state
from atlas.reason.planner import ActionPlanner, FillPlan
from atlas.target.base import TargetAdapter
from atlas.understanding.fields import discover_fields
from atlas.understanding.source import SourceReader, SourceRecord
from atlas.vision.models import SceneDescription
from atlas.vision.scene import SceneAnalysis

ACTION_STATE = {
    ActionType.TYPE: AgentState.TYPING,
    ActionType.PASTE: AgentState.TYPING,
    ActionType.CLEAR: AgentState.TYPING,
    ActionType.SELECT: AgentState.TYPING,
    ActionType.TOGGLE: AgentState.TYPING,
    ActionType.CHOOSE_DATE: AgentState.TYPING,
    ActionType.TAB: AgentState.TYPING,
    ActionType.PRESS_ENTER: AgentState.TYPING,
    ActionType.PRESS_ESCAPE: AgentState.TYPING,
    ActionType.CLICK: AgentState.CLICKING,
    ActionType.DOUBLE_CLICK: AgentState.CLICKING,
    ActionType.RIGHT_CLICK: AgentState.CLICKING,
    ActionType.HOVER: AgentState.CLICKING,
    ActionType.MOVE_MOUSE: AgentState.CLICKING,
    ActionType.SUBMIT: AgentState.UPLOADING,
    ActionType.SCROLL: AgentState.SCROLLING,
    ActionType.WAIT: AgentState.WAITING,
    ActionType.VERIFY: AgentState.VERIFYING,
    ActionType.CAPTURE: AgentState.ANALYZING,
    ActionType.ANALYZE: AgentState.ANALYZING,
    ActionType.STOP: AgentState.STOPPED,
}


@dataclass
class RecordResult:
    """Outcome of processing one source record."""

    index: int
    record: SourceRecord
    mapping: MappingResult
    actions: list[ActionResult] = field(default_factory=list)
    skipped_fields: list[str] = field(default_factory=list)
    success: bool = False
    incomplete_fields: list[str] = field(default_factory=list)
    duration_ms: float = 0.0
    message: str = ""

    def to_dict(self) -> dict:
        return {
            "index": self.index,
            "record": self.record.to_dict(),
            "mapping": self.mapping.to_dict(),
            "actions": [a.to_dict() for a in self.actions],
            "skipped_fields": list(self.skipped_fields),
            "success": self.success,
            "incomplete_fields": list(self.incomplete_fields),
            "duration_ms": self.duration_ms,
            "message": self.message,
        }


@dataclass
class WorkflowSummary:
    """Aggregate of a whole workflow run."""

    records: list[RecordResult] = field(default_factory=list)
    started: float = field(default_factory=time.time)
    finished: float = 0.0
    stopped_reason: str = ""

    @property
    def completed(self) -> int:
        return sum(1 for r in self.records if r.success)

    @property
    def failed(self) -> int:
        return sum(1 for r in self.records if not r.success)

    @property
    def total_duration(self) -> float:
        return self.finished - self.started if self.finished else 0.0

    @property
    def fields_filled(self) -> int:
        return sum(len(r.actions) for r in self.records)

    def to_dict(self) -> dict:
        return {
            "records": [r.to_dict() for r in self.records],
            "completed": self.completed,
            "failed": self.failed,
            "total_duration": self.total_duration,
            "stopped_reason": self.stopped_reason,
        }


class AgentLoop:
    """Runs the observe -> ... -> verify loop until records run out."""

    def __init__(
        self,
        target: TargetAdapter,
        source_reader: SourceReader,
        mapper: SemanticMapper,
        planner: ActionPlanner,
        executor: ActionExecutor,
        memory: Any | None = None,
        verify_after_action: bool = True,
        max_records: int = 0,
        next_record_timeout: float = 120.0,
        next_record_poll: float = 1.5,
        alias_learning: bool = False,
        scene_hook: Callable[[SceneDescription], SceneDescription] | None = None,
        on_record: Callable[[RecordResult], None] | None = None,
    ) -> None:
        self._target = target
        self._source_reader = source_reader
        self._mapper = mapper
        self._planner = planner
        self._executor = executor
        self._memory = memory
        self._verify_after_action = verify_after_action
        self._max_records = max_records
        self._next_timeout = next_record_timeout
        self._next_poll = next_record_poll
        self._alias_learning = alias_learning
        self._scene_hook = scene_hook
        self._on_record = on_record
        self._states = StateMachine()
        self._stop = False
        self._pause = False
        self._last_layout = ""
        self._bus = get_event_bus()

    # -- lifecycle -----------------------------------------------------------

    @property
    def state(self) -> AgentState:
        return self._states.state

    def stop(self) -> None:
        self._stop = True

    def pause(self) -> None:
        self._pause = True

    def resume(self) -> None:
        self._pause = False

    def run(self) -> WorkflowSummary:
        summary = WorkflowSummary()
        self._states.reset()
        self._bus.publish(EventType.AGENT_STARTED)
        try:
            if not self._target.is_alive():
                raise RuntimeError("target is not attached")
            count = 0
            last_key: str | None = None
            while not self._stop:
                if self._max_records and count >= self._max_records:
                    summary.stopped_reason = f"max_records reached ({count})"
                    break
                if self._pause:
                    time.sleep(0.2)
                    continue
                analysis = self._wait_for_first_record(last_key)
                if analysis is None:
                    summary.stopped_reason = "no record available"
                    break
                record = self._run_record(analysis, count + 1)
                summary.records.append(record)
                count += 1
                if self._on_record is not None:
                    try:
                        self._on_record(record)
                    except Exception:
                        logger.exception("on_record callback failed")
                last_key = record.record.record_key
                self._bus.publish(
                    EventType.RECORD_COMPLETED if record.success else EventType.RECORD_FAILED,
                    record.to_dict(),
                )
        except Exception as exc:
            logger.exception("workflow failed")
            summary.stopped_reason = str(exc)
        finally:
            summary.finished = time.time()
            self._states.transition(AgentState.STOPPED)
            self._bus.publish(EventType.WORKFLOW_COMPLETE, summary.to_dict())
            self._bus.publish(EventType.AGENT_STOPPED, {"reason": summary.stopped_reason})
        return summary

    # -- record processing ----------------------------------------------------

    def _run_record(self, analysis: SceneAnalysis, index: int) -> RecordResult:
        with Timer() as timer:
            self._set(AgentState.OBSERVING)
            scene = analysis.scene
            self._set(AgentState.UNDERSTANDING)
            record = self._source_reader.read(scene)
            self._bus.publish(EventType.SOURCE_READ, record.to_dict())
            self._bus.publish(EventType.RECORD_STARTED, {"index": index, "record": record.to_dict()})

            fields = discover_fields(scene)
            self._bus.publish(
                EventType.FIELD_DISCOVERED, {"count": len(fields), "fields": [f.to_dict() for f in fields]}
            )

            self._set(AgentState.PLANNING)
            mapping = self._mapper.map(record, fields)
            self._bus.publish(EventType.MAPPING, mapping.to_dict())

            submit_id = self._find_submit(scene)
            plan = self._planner.plan_fill(record, mapping, scene, submit_id)
            self._bus.publish(EventType.PLAN_CREATED, plan.to_dict())

        self._set(AgentState.THINKING)
        results = self._execute_plan(plan)
        self._bus.publish(
            EventType.SCREEN_STATE,
            build_screen_state(
                scene=scene,
                record=record,
                mapping=mapping,
                results=results,
                window_title=getattr(getattr(self._target, "info", None), "title", "") or "",
                record_index=index,
            ),
        )

        result = RecordResult(
            index=index,
            record=record,
            mapping=mapping,
            actions=results,
            success=self._all_ok(results),
            duration_ms=timer.elapsed * 1000.0,
        )
        self._learn_aliases(record, mapping, results)
        result.incomplete_fields = self._unmapped_required(mapping)
        result.skipped_fields = self._skipped_fields(results)
        if result.skipped_fields or result.incomplete_fields:
            result.message = (
                f"skipped {len(result.skipped_fields)} field(s), "
                f"{len(result.incomplete_fields)} required unmapped"
            )
        logger.info(
            "record {} ({}) -> {} in {:.1f}s",
            index,
            record.record_key or "?",
            "OK" if result.success else "FAILED",
            result.duration_ms / 1000.0,
        )
        return result

    def _execute_plan(self, plan: FillPlan) -> list[ActionResult]:
        results: list[ActionResult] = []
        for action in plan.actions:
            if self._stop:
                break
            if action.type == ActionType.SUBMIT:
                self._bus.publish(EventType.UPLOADING, action.to_dict())
            self._set(ACTION_STATE.get(action.type, AgentState.THINKING))
            self._bus.publish(EventType.ACTION_STARTED, action.to_dict())
            result = self._executor.execute(action)
            results.append(result)
            if result.ok and action.type == ActionType.SUBMIT:
                self._bus.publish(EventType.UPLOAD_COMPLETED, result.to_dict())
            if not result.ok and action.type in {ActionType.SUBMIT, ActionType.CLICK}:
                logger.warning("submit/click failed; stopping record: {}", result.message)
                break
        return results

    # -- helpers --------------------------------------------------------------

    def _wait_for_first_record(self, previous_key: str | None) -> SceneAnalysis | None:
        """Observe until a source record is available (first record or next)."""
        self._set(AgentState.WATCHING)
        deadline = time.time() + self._next_timeout
        while not self._stop and time.time() < deadline:
            analysis = self._observe()
            if analysis is None:
                time.sleep(self._next_poll)
                continue
            record = self._source_reader.read(analysis.scene)
            key = record.record_key
            if key and key != previous_key:
                self._bus.publish(EventType.NEXT_RECORD_DETECTED, {"key": key})
                return analysis
            if not record.pairs:
                time.sleep(self._next_poll)
                continue
            if key is None and analysis.scene.layout_summary != (self._last_layout or ""):
                self._last_layout = analysis.scene.layout_summary
                return analysis
            self._bus.publish(EventType.NEXT_RECORD_WAITING, {"key": key})
            time.sleep(self._next_poll)
        self._set(AgentState.STOPPED)
        return None

    def _observe(self) -> SceneAnalysis | None:
        self._set(AgentState.OBSERVING)
        analysis = self._target.observe()
        if analysis is not None:
            if self._scene_hook is not None:
                try:
                    analysis.scene = self._scene_hook(analysis.scene)
                except Exception:
                    logger.exception("scene hook failed; using raw scene")
            self._bus.publish(EventType.OBSERVED, analysis.to_dict())
        return analysis

    def _find_submit(self, scene: SceneDescription) -> str | None:
        submitish = (
            "upload", "submit", "save", "next", "ok", "apply", "continue",
            "done", "finish", "update", "register", "create", "add", "confirm",
        )
        buttons = [
            e
            for e in scene.elements
            if e.type.value in {"button", "submit"} or e.section == "actions"
        ]
        for label_token in submitish:
            for e in buttons:
                if label_token in (e.label or "").lower() and e.bbox is not None:
                    return e.element_id
        for e in buttons:
            if e.bbox is not None:
                return e.element_id
        for label_token in submitish:
            for e in buttons:
                if label_token in (e.label or "").lower():
                    return e.element_id
        for e in buttons:
            return e.element_id
        return None

    def _all_ok(self, results: list[ActionResult]) -> bool:
        if not results:
            return False
        return all(r.ok for r in results)

    @staticmethod
    def _skipped_fields(results: list[ActionResult]) -> list[str]:
        skipped = []
        for r in results:
            if r.success is False and r.action.field_id:
                skipped.append(r.action.field_id)
        return skipped

    @staticmethod
    def _unmapped_required(mapping: MappingResult) -> list[str]:
        return [f.label for f in mapping.unmatched_fields if f.element.required]

    def _learn_aliases(self, record: SourceRecord, mapping: MappingResult, results: list[ActionResult]) -> None:
        """Conservatively remember fuzzy mappings that verified successfully."""
        if not self._alias_learning or self._memory is None:
            return
        verified_ids = {r.action.field_id for r in results if r.ok}
        for m in mapping.mappings:
            if m.method in {"token", "containment", "fuzzy"} and m.confidence >= 0.9 and m.target_id in verified_ids:
                try:
                    self._memory.learn_alias(m.source_label, m.target_label)
                    self._mapper.aliases.learn(m.source_label, m.target_label)
                except Exception as exc:
                    logger.debug("alias learning skipped: {}", exc)

    def _set(self, state: AgentState) -> None:
        try:
            self._states.transition(state)
        except Exception:
            try:
                self._states.force(state)
            except Exception:
                pass
        self._bus.publish(EventType.STATE_CHANGED, {"state": self._states.state.value})


__all__ = ["AgentLoop", "RecordResult", "WorkflowSummary"]
