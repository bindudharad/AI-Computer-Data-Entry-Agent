"""Window client-area capture.

Attaches to a single target window and captures ONLY its client area, returning
the image as a numpy array together with the offset of the client area on the
physical screen (so element boxes can be translated to absolute screen
coordinates for mouse actions).
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

import numpy as np

from atlas.core.logging import logger

try:
    import mss
    import mss.tools
except ImportError:  # pragma: no cover - dependency guard
    mss = None  # type: ignore[assignment]


@dataclass
class ClientArea:
    """A captured client area plus the geometry needed to act on it."""

    image: np.ndarray  # RGB (H, W, 3)
    left: int  # screen x of client origin
    top: int  # screen y of client origin
    width: int
    height: int

    def to_screen(self, x: int, y: int) -> tuple[int, int]:
        """Translate capture-relative coordinates to absolute screen coords."""
        return self.left + x, self.top + y

    @property
    def offset(self) -> tuple[int, int]:
        return (self.left, self.top)

    def save(self, path: Any) -> None:
        from PIL import Image

        Image.fromarray(self.image).save(path)


class ScreenGrabber:
    """Low-level screen grabber using mss."""

    def __init__(self) -> None:
        if mss is None:
            raise RuntimeError("mss is required for screen capture")
        self._mss = mss.mss()

    def grab_rect(self, left: int, top: int, width: int, height: int) -> np.ndarray:
        """Grab a rectangle and return an RGB numpy array."""
        shot = self._mss.grab({"left": left, "top": top, "width": width, "height": height})
        arr = np.frombuffer(shot.raw, dtype=np.uint8).reshape(shot.height, shot.width, 4)
        return arr[:, :, :3][:, :, ::-1].copy()  # BGRA -> RGB

    def close(self) -> None:
        try:
            self._mss.close()
        except Exception:
            pass


class WindowGeometry:
    """Windows API helpers for locating windows and their client areas."""

    @staticmethod
    def client_area(handle: int) -> tuple[int, int, int, int]:
        """Return (left, top, width, height) of the client area in screen coords."""
        import win32gui

        rect = win32gui.GetClientRect(handle)
        width, height = rect[2], rect[3]
        origin = win32gui.ClientToScreen(handle, (0, 0))
        return origin[0], origin[1], width, height

    @staticmethod
    def window_title(handle: int) -> str:
        import win32gui

        try:
            return win32gui.GetWindowText(handle) or ""
        except Exception:
            return ""

    @staticmethod
    def find_window_by_title(title: str) -> int | None:
        import win32gui

        def _collect(handle: int, acc: list[int]) -> None:
            if not win32gui.IsWindowVisible(handle):
                return
            try:
                text = win32gui.GetWindowText(handle) or ""
            except Exception:
                text = ""
            if title.lower() in text.lower():
                acc.append(handle)

        matches: list[int] = []
        win32gui.EnumWindows(_collect, matches)  # type: ignore[arg-type]
        return matches[0] if matches else None


class WindowCapture:
    """Captures only the client area of an attached window.

    All scene-analysis coordinates are relative to ``ClientArea.image``; the
    ``screen_offset`` bridges from the capture to the physical screen.
    """

    def __init__(self, grabber: ScreenGrabber | None = None, monitor: int = 0) -> None:
        self._grabber = grabber or ScreenGrabber()
        self._monitor = monitor
        self.handle: int | None = None
        self.title: str = ""
        self.last_capture: ClientArea | None = None

    def attach(self, handle: int, title: str = "") -> None:
        """Attach to a specific window handle."""
        self.handle = handle
        self.title = title or WindowGeometry.window_title(handle)

    def detach(self) -> None:
        self.handle = None
        self.title = ""
        self.last_capture = None

    @property
    def attached(self) -> bool:
        return self.handle is not None

    def client_area(self) -> ClientArea | None:
        """Capture the client area of the attached window (guard rails included).

        Returns None if capture is unavailable (window closed, zero-size, ...).
        """
        if self.handle is None:
            return None
        try:
            left, top, width, height = WindowGeometry.client_area(self.handle)
        except Exception as exc:
            logger.debug("client_area failed for handle {}: {}", self.handle, exc)
            return None
        if width <= 0 or height <= 0 or width > 20000 or height > 20000:
            return None
        try:
            image = self._grabber.grab_rect(left, top, width, height)
        except Exception as exc:
            logger.debug("grab failed: {}", exc)
            return None
        area = ClientArea(image=image, left=left, top=top, width=width, height=height)
        self.last_capture = area
        return area

    def capture_until_nonempty(self, timeout: float = 8.0, poll: float = 0.5) -> ClientArea | None:
        """Capture, retrying briefly while the client area is blank."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            area = self.client_area()
            if area is not None and area.image.shape[0] > 2 and area.image.shape[1] > 2:
                brightness = float(np.mean(area.image))
                if brightness > 1.0:  # not a pure-black capture
                    self.last_capture = area
                    return area
            time.sleep(poll)
        return self.last_capture

    def close(self) -> None:
        self.detach()
        self._grabber.close()
