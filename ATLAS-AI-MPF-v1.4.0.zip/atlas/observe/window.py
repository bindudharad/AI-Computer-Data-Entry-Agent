"""Window attachment.

The agent attaches to a single target window (selected by the user clicking its
first editable field, or by title/handle). From then on it observes ONLY that
window's client area - ignoring taskbar, desktop, notifications, other monitors
and any overlay it draws on top.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

import win32api
import win32con
import win32gui

from atlas.core.logging import logger
from atlas.vision.capture import WindowCapture


class AttachError(RuntimeError):
    """Raised when a window cannot be attached/focused."""


@dataclass
class WindowTarget:
    """A resolved target window."""

    handle: int
    title: str
    process_id: int
    executable: str = ""

    def to_dict(self) -> dict:
        return {
            "handle": self.handle,
            "title": self.title,
            "process_id": self.process_id,
            "executable": self.executable,
        }


class WindowAttacher:
    """Resolves and brings a target window to the foreground.

    ``attach`` is called after the user clicks the first editable field (the
    foreground window at that moment becomes the target). The foreground window
    is the application the user just interacted with, which is exactly the
    window we should confine observation to.
    """

    def __init__(self, capture: WindowCapture) -> None:
        self._capture = capture

    def attach_foreground(self) -> WindowTarget:
        """Attach to the currently foreground (active) top-level window."""
        handle = win32gui.GetForegroundWindow()
        if not handle:
            raise AttachError("no foreground window available")
        target = self._resolve(handle)
        self._capture.attach(target.handle, target.title)
        return target

    def attach_by_title(self, title: str) -> WindowTarget:
        """Attach to the first visible top-level window whose title matches."""
        from atlas.vision.capture import WindowGeometry

        handle = WindowGeometry.find_window_by_title(title)
        if handle is None:
            raise AttachError(f"no window found matching title {title!r}")
        target = self._resolve(handle)
        self._capture.attach(target.handle, target.title)
        return target

    def attach_by_handle(self, handle: int) -> WindowTarget:
        if not win32gui.IsWindow(handle):
            raise AttachError(f"invalid window handle {handle}")
        target = self._resolve(handle)
        self._capture.attach(target.handle, target.title)
        return target

    def bring_to_front(self, target: WindowTarget) -> None:
        """Restore and foreground the target window (best-effort)."""
        try:
            if win32gui.IsIconic(target.handle):
                win32gui.ShowWindow(target.handle, win32con.SW_RESTORE)
            win32gui.SetForegroundWindow(target.handle)
            time.sleep(0.15)
        except Exception as exc:
            logger.warning("could not bring window to front: {}", exc)

    def verify_focused(self, target: WindowTarget) -> bool:
        """Check that the target window is currently the foreground window."""
        try:
            return win32gui.GetForegroundWindow() == target.handle
        except Exception:
            return False

    def focus_and_verify(self, target: WindowTarget, retries: int = 3) -> bool:
        for _ in range(retries):
            if self.verify_focused(target):
                return True
            self.bring_to_front(target)
            time.sleep(0.2)
        return self.verify_focused(target)

    def _resolve(self, handle: int) -> WindowTarget:
        title = win32gui.GetWindowText(handle) or ""
        try:
            _, pid = win32gui.GetWindowThreadProcessId(handle)
        except Exception:
            pid = 0
        exe = self._executable_for(pid)
        return WindowTarget(handle=handle, title=title, process_id=pid, executable=exe)

    @staticmethod
    def _executable_for(pid: int) -> str:
        try:
            import psutil

            return psutil.Process(pid).name()
        except Exception:
            return ""


def window_under_cursor() -> WindowTarget | None:
    """Return the top-level window under the current cursor position."""
    try:
        pos = win32api.GetCursorPos()
        handle = win32gui.WindowFromPoint(pos)
        if not handle:
            return None
        # climb to the top-level owner
        while win32gui.GetParent(handle):
            handle = win32gui.GetParent(handle)
        title = win32gui.GetWindowText(handle) or ""
        try:
            _, pid = win32gui.GetWindowThreadProcessId(handle)
        except Exception:
            pid = 0
        return WindowTarget(handle=handle, title=title, process_id=pid)
    except Exception:
        return None


__all__ = ["WindowAttacher", "WindowTarget", "AttachError", "window_under_cursor"]
