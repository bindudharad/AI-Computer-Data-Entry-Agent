# ATLAS AI

An AI-first Windows computer agent that fills data-entry forms end to end. A
vision-language model drives every decision through the loop:

```
Observe -> Understand -> Reason -> Plan -> Execute -> Verify -> Observe
```

VLM perception is the primary channel; OCR is only an explicit fallback for
"read this tiny printed text" requests.

## Highlights

- **Vision-first perception** - a VLM converts each screenshot into a typed
  scene (fields, buttons, labels, values) instead of fragile OCR heuristics.
- **Two targets, one loop** - the same workflow runs against a native desktop
  window or a web page. Web targets add a DOM index so click/fill/read-back
  work without coordinate fragility.
- **Human-like acting** - bezier mouse movement, typed keystrokes, clipboard
  fast-path for long values, simulated typos.
- **Verified actions** - every value-producing action is read back (DOM value,
  clipboard, or OCR region) before continuing; failures retry and feed the
  recovery planner.
- **Two-pass semantic mapping** - exact/alias matches claim targets first, then
  fuzzy matching; cross-concept fuzzy collisions are blocked, and verified
  fuzzy mappings persist to SQLite memory.
- **Observable** - state machine, event bus, floating status overlay, and a
  localhost JSON command server for remote control.

## Requirements

- Windows 10/11, Python 3.10+
- Core deps in `requirements.txt`, optional extras in `requirements-optional.txt`
  (OpenCV, PaddleOCR, Playwright browsers).

## Install

```powershell
pip install -r requirements.txt
pip install -r requirements-optional.txt   # optional: vision/OCR/browser extras
python -m playwright install chromium      # if using --web
python main.py doctor                      # verify the environment
```

## Quick start

Desktop target (attach by window title):

```powershell
python main.py run --title "Customer Entry"
```

Web target (Playwright):

```powershell
python main.py run --web --url http://localhost:5173 --max-records 3
```

Serve the JSON command endpoint:

```powershell
python main.py serve
```

## CLI

```
python main.py run    --web|--title TITLE [--url URL] [--browser chromium|firefox|webkit]
                      [--headless] [--max-records N] [--no-overlay] [--json]
python main.py serve  [--port PORT]
python main.py doctor
python main.py version
```

## Configuration

Everything is configurable through environment variables or a `.env` file. See
`docs/configuration.md` for the full table.

## Testing and quality

```powershell
python -m pytest tests -q        # 66 tests: unit + Playwright E2E
python -m ruff check atlas main.py tests
python -m mypy --config-file pyproject.toml atlas
```

## Project layout

```
atlas/
  act/           executor, controls, keyboard/mouse/clipboard, verification
  assistant/     Assistant facade + Controller (JSON command server)
  core/          events, logging, metrics, state machine, settings
  mapping/       source -> target field mapping (exact/fuzzy + alias store)
  memory/        SQLite memory (learned aliases)
  observe/       capture, window attach, change watcher
  overlay/       floating status overlay
  plugins/       plugin manager (hooks for register/event/record/close)
  reason/        planner, recovery planner, LLM advisor
  target/        TargetAdapter, DesktopTarget, WebTarget (DOM)
  understanding/ source record extraction, field discovery
  vision/        VLM providers, scene analyzer, OCR, debug rendering
  workflow/      AgentLoop + WorkflowSummary
docs/            architecture, targets, configuration, development
main.py          CLI entry point
tests/           unit + E2E tests
```

## Documentation

- `docs/architecture.md` - pipeline, modules, interfaces
- `docs/targets.md` - desktop and web targets
- `docs/configuration.md` - environment variables
- `docs/development.md` - testing and static analysis
