"""Plugin system.

A minimal hook-based plugin system: plugins register with the manager and are
notified of agent events and per-record results. No dynamic loading magic -
plugins are plain modules discovered from ``atlas/plugins/builtin`` or a user
directory, exposing a ``register_plugin()`` function.
"""

from __future__ import annotations

import importlib
import inspect
import pkgutil
from abc import ABC
from pathlib import Path
from typing import Any

from atlas.core.events import Event
from atlas.core.logging import logger


class Plugin(ABC):
    """Base class for agent plugins."""

    name = "plugin"

    def on_register(self, assistant: Any) -> None:
        """Called once when the plugin is attached to the assistant."""

    def on_event(self, event: Event) -> None:
        """Called for every event published on the bus."""

    def on_record(self, record: Any) -> None:
        """Called after each record completes."""

    def close(self) -> None:
        """Release plugin resources."""


class PluginManager:
    """Registers plugins and forwards events / records to them."""

    def __init__(self, assistant: Any = None) -> None:
        self._assistant = assistant
        self._plugins: list[Plugin] = []

    @property
    def plugins(self) -> list[Plugin]:
        return list(self._plugins)

    @property
    def names(self) -> list[str]:
        return [p.name for p in self._plugins]

    def register(self, plugin: Plugin) -> None:
        if any(p.name == plugin.name for p in self._plugins):
            logger.debug("plugin '{}' already registered", plugin.name)
            return
        self._plugins.append(plugin)
        if self._assistant is not None:
            try:
                plugin.on_register(self._assistant)
            except Exception:
                logger.exception("plugin {} failed on_register", plugin.name)
        logger.info("plugin registered: {}", plugin.name)

    def load_from(self, directory: str | Path) -> int:
        """Import every module in ``directory`` and register its plugins."""
        path = Path(directory)
        if not path.is_dir():
            return 0
        found = 0
        for module_info in pkgutil.iter_modules([str(path)]):
            try:
                module = importlib.import_module(f"{path.name}.{module_info.name}")
            except Exception as exc:
                logger.warning("failed to import plugin module {}: {}", module_info.name, exc)
                continue
            factory = getattr(module, "register_plugin", None)
            plugin: Plugin | None = None
            if callable(factory):
                plugin = factory()
            else:
                for _, candidate in inspect.getmembers(module, inspect.isclass):
                    if issubclass(candidate, Plugin) and candidate is not Plugin:
                        plugin = candidate()
                        break
            if isinstance(plugin, Plugin):
                self.register(plugin)
                found += 1
        return found

    def event(self, event: Event) -> None:
        for plugin in self._plugins:
            try:
                plugin.on_event(event)
            except Exception:
                logger.exception("plugin {} failed on_event", plugin.name)

    def record(self, record: Any) -> None:
        for plugin in self._plugins:
            try:
                plugin.on_record(record)
            except Exception:
                logger.exception("plugin {} failed on_record", plugin.name)

    def close(self) -> None:
        for plugin in self._plugins:
            try:
                plugin.close()
            except Exception:
                pass
        self._plugins.clear()


__all__ = ["Plugin", "PluginManager"]
