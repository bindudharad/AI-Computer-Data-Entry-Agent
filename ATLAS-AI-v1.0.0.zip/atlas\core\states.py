"""Agent state machine.

The floating assistant and the workflow loop both render this state. States map
to the full lifecycle: idle -> waiting for attach -> watching -> analyzing ->
planning -> acting (typing/clicking/scrolling) -> verifying -> done, with
pause/stop/error/recovery as cross-cutting states.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable
from enum import Enum


class AgentState(str, Enum):
    """All observable states of the agent."""

    IDLE = "idle"
    WAITING_ATTACH = "waiting_attach"  # waiting for the user to click a field
    ATTACHING = "attaching"
    WATCHING = "watching"
    ANALYZING = "analyzing"
    PLANNING = "planning"
    THINKING = "thinking"
    TYPING = "typing"
    CLICKING = "clicking"
    SCROLLING = "scrolling"
    WAITING = "waiting"  # waiting for a new record
    VERIFYING = "verifying"
    COMPLETED = "completed"
    PAUSED = "paused"
    STOPPED = "stopped"
    ERROR = "error"
    RECOVERY = "recovery"


#: User-initiated states that may be entered from any running state.
_INTERRUPT_STATES = {AgentState.PAUSED, AgentState.STOPPED}

#: States in which the agent is actively executing work.
_ACTIVE_STATES = {
    AgentState.ATTACHING,
    AgentState.WATCHING,
    AgentState.ANALYZING,
    AgentState.PLANNING,
    AgentState.THINKING,
    AgentState.TYPING,
    AgentState.CLICKING,
    AgentState.SCROLLING,
    AgentState.WAITING,
    AgentState.VERIFYING,
    AgentState.RECOVERY,
}


class InvalidTransitionError(RuntimeError):
    """Raised when a state transition is not allowed."""


class StateMachine:
    """Small, explicit transition state machine.

    Valid transitions:

    IDLE -> WAITING_ATTACH -> ATTACHING -> WATCHING -> ANALYZING -> PLANNING
        -> THINKING -> {TYPING, CLICKING, SCROLLING} -> VERIFYING -> WATCHING
    WATCHING/VERIFYING -> COMPLETED -> WAITING -> WATCHING
    <active> -> PAUSED -> <prior active>
    <any running> -> STOPPED (terminal)
    <any> -> ERROR -> <recovery/active/stopped>
    """

    def __init__(self, initial: AgentState = AgentState.IDLE) -> None:
        self._state = initial
        self._on_change: list[Callable[[AgentState], None]] = []
        self._resume_state: AgentState | None = None

    @property
    def state(self) -> AgentState:
        return self._state

    def is_active(self) -> bool:
        return self._state in _ACTIVE_STATES

    def can_pause(self) -> bool:
        return self.is_active() or self._state == AgentState.COMPLETED

    def on_change(self, listener: Callable[[AgentState], None]) -> None:
        """Register a listener notified with the new state on every change."""
        self._on_change.append(listener)

    def transition(self, new_state: AgentState) -> AgentState:
        """Attempt a transition, enforcing the transition table."""
        current = self._state
        if new_state == current:
            return current
        if not self._is_valid(current, new_state):
            raise InvalidTransitionError(f"{current.value} -> {new_state.value} not allowed")
        if new_state in _INTERRUPT_STATES:
            if current in _ACTIVE_STATES or current == AgentState.COMPLETED:
                self._resume_state = current
            else:
                self._resume_state = None
        elif current in _INTERRUPT_STATES and new_state == AgentState.PAUSED:
            pass  # resume handled below
        self._state = new_state
        for listener in self._on_change:
            try:
                listener(new_state)
            except Exception:
                pass
        return self._state

    def force(self, state: AgentState) -> AgentState:
        """Set the state directly, bypassing the transition table.

        Used only by the workflow loop to recover its position after a reset or
        an unexpected error; never for user-initiated transitions.
        """
        self._state = state
        self._resume_state = None
        for listener in self._on_change:
            try:
                listener(state)
            except Exception:
                pass
        return self._state

    def resume(self) -> AgentState:
        """Return to the state before pause."""
        if self._state == AgentState.PAUSED:
            target = self._resume_state or AgentState.WATCHING
            self._resume_state = None
            return self.force(target)
        return self._state

    def reset(self) -> None:
        self._resume_state = None
        self.force(AgentState.IDLE)

    @staticmethod
    def _is_valid(current: AgentState, new_state: AgentState) -> bool:
        if new_state in _INTERRUPT_STATES:
            return True  # pause/stop always allowed
        if current == AgentState.IDLE:
            return new_state == AgentState.WAITING_ATTACH
        if current == AgentState.WAITING_ATTACH:
            return new_state in {AgentState.ATTACHING, AgentState.ERROR, AgentState.IDLE}
        if current == AgentState.ATTACHING:
            return new_state in {AgentState.WATCHING, AgentState.ERROR, AgentState.IDLE}
        if current == AgentState.WATCHING:
            return new_state in {
                AgentState.ANALYZING,
                AgentState.COMPLETED,
                AgentState.WAITING,
                AgentState.ERROR,
            }
        if current == AgentState.ANALYZING:
            return new_state in {AgentState.PLANNING, AgentState.ERROR, AgentState.RECOVERY}
        if current == AgentState.PLANNING:
            return new_state in {
                AgentState.THINKING,
                AgentState.ERROR,
                AgentState.RECOVERY,
            }
        if current == AgentState.THINKING:
            return new_state in {
                AgentState.TYPING,
                AgentState.CLICKING,
                AgentState.SCROLLING,
                AgentState.ERROR,
                AgentState.RECOVERY,
            }
        if current in {AgentState.TYPING, AgentState.CLICKING, AgentState.SCROLLING}:
            return new_state in {
                AgentState.VERIFYING,
                AgentState.ERROR,
                AgentState.RECOVERY,
                AgentState.WATCHING,
            }
        if current == AgentState.VERIFYING:
            return new_state in {
                AgentState.WATCHING,
                AgentState.COMPLETED,
                AgentState.ERROR,
                AgentState.RECOVERY,
            }
        if current == AgentState.COMPLETED:
            return new_state in {AgentState.WAITING, AgentState.WATCHING, AgentState.IDLE}
        if current == AgentState.WAITING:
            return new_state in {AgentState.WATCHING, AgentState.ERROR, AgentState.STOPPED}
        if current == AgentState.ERROR:
            return new_state in {
                AgentState.RECOVERY,
                AgentState.WATCHING,
                AgentState.IDLE,
                AgentState.STOPPED,
            }
        if current == AgentState.RECOVERY:
            return new_state in {
                AgentState.WATCHING,
                AgentState.ANALYZING,
                AgentState.IDLE,
                AgentState.ERROR,
            }
        return False


def states_prioritized() -> Iterable[AgentState]:
    """Ordered states for display in debug UIs."""
    return list(AgentState)
