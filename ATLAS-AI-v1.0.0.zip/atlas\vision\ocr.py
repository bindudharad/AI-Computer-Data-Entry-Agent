"""OCR fallback.

OCR is used ONLY when the agent explicitly requests reading tiny printed text
(e.g. small captions, confirmation codes) and never as part of the primary
scene understanding channel. Two backends are supported behind one interface:
PaddleOCR (default) and Tesseract.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import numpy as np

from atlas.config import OcrConfig
from atlas.vision.models import BBox, OcrText


class OcrReader(ABC):
    """Interface for the local OCR fallback engine."""

    name = "abstract"

    @abstractmethod
    def read_image(self, image: np.ndarray) -> list[OcrText]:
        """Return OCR lines with bounding boxes and confidence."""

    def read_region(self, image: np.ndarray, region: BBox) -> list[OcrText]:
        """OCR a sub-region; returned boxes are offset to the full image."""
        crop = image[region.top : region.bottom, region.left : region.right]
        if crop.size == 0:
            return []
        lines = self.read_image(crop)
        for line in lines:
            line.bbox = line.bbox.shifted(region.left, region.top)
        return lines

    def close(self) -> None:
        pass


class PaddleOcrReader(OcrReader):
    """PaddleOCR backend."""

    name = "paddle"

    def __init__(self, config: OcrConfig | None = None) -> None:
        self._config = config or OcrConfig()
        self._engine: Any = None
        self._available: bool | None = None

    def _ensure_engine(self) -> Any:
        if self._engine is not None:
            return self._engine
        try:
            from paddleocr import PaddleOCR
        except ImportError:
            self._available = False
            raise RuntimeError(
                "PaddleOCR not installed - run `pip install -r requirements-optional.txt`"
            )
        self._available = True
        # v3 keeps kwargs for the constructor; use_angle_cls is v2 style.
        try:
            self._engine = PaddleOCR(use_angle_cls=True, lang=self._config.lang, show_log=False)
        except TypeError:
            self._engine = PaddleOCR(lang=self._config.lang, show_log=False)
        return self._engine

    @property
    def available(self) -> bool:
        if self._available is None:
            try:
                self._ensure_engine()
            except Exception:
                self._available = False
        return bool(self._available)

    def read_image(self, image: np.ndarray) -> list[OcrText]:
        engine = self._ensure_engine()
        if image.ndim == 2:
            image = np.stack([image] * 3, axis=-1)
        bgr = image[:, :, ::-1]
        result = engine.ocr(bgr, cls=True)
        return self._parse(result)

    def _parse(self, result: Any) -> list[OcrText]:
        lines: list[OcrText] = []
        if not result:
            return lines

        # PaddleOCR v3 dict format.
        if isinstance(result, dict):
            texts = result.get("rec_texts") or []
            scores = result.get("rec_scores") or []
            polys = result.get("rec_polys") or []
            for text, score, poly in zip(texts, scores, polys, strict=False):
                xs = [p[0] for p in poly]
                ys = [p[1] for p in poly]
                if xs and ys:
                    box = BBox(min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys))
                    lines.append(OcrText(text=str(text), bbox=box, confidence=float(score)))
            return lines

        # PaddleOCR v2 list-of-pages format.
        page = result[0]
        if not page:
            return lines
        for item in page:
            if not isinstance(item, (list, tuple)) or len(item) < 2:
                continue
            quad, text_conf = item[0], item[1]
            text, score = text_conf
            xs = [p[0] for p in quad]
            ys = [p[1] for p in quad]
            if xs and ys:
                box = BBox(int(min(xs)), int(min(ys)), int(max(xs) - min(xs)), int(max(ys) - min(ys)))
                lines.append(OcrText(text=str(text), bbox=box, confidence=float(score)))
        return lines


class TesseractOcrReader(OcrReader):
    """Tesseract backend (requires pytesseract + binary)."""

    name = "tesseract"

    def __init__(self, config: OcrConfig | None = None) -> None:
        self._config = config or OcrConfig()
        self._available: bool | None = None

    def _ensure(self) -> Any:
        try:
            import pytesseract  # type: ignore
        except ImportError as exc:
            raise RuntimeError("pytesseract not installed") from exc
        self._available = True
        return pytesseract

    @property
    def available(self) -> bool:
        if self._available is None:
            try:
                self._ensure()
            except Exception:
                self._available = False
        return bool(self._available)

    def read_image(self, image: np.ndarray) -> list[OcrText]:
        from PIL import Image

        pytesseract = self._ensure()
        pil = Image.fromarray(image)
        data = pytesseract.image_to_data(pil, lang=self._config.lang, output_type="dict")
        lines: list[OcrText] = []
        for text, conf, left, top, w, h in zip(
            data["text"], data["conf"], data["left"], data["top"], data["width"], data["height"], strict=False
        ):
            text = (text or "").strip()
            if not text:
                continue
            try:
                score = float(conf) / 100.0
            except (TypeError, ValueError):
                score = 0.0
            if score < self._config.confidence_threshold:
                continue
            lines.append(OcrText(text=text, bbox=BBox(left, top, w, h), confidence=score))
        return lines


class NoopOcrReader(OcrReader):
    """No-op backend (OCR disabled)."""

    name = "none"

    def read_image(self, image: np.ndarray) -> list[OcrText]:
        return []


def create_ocr_reader(config: OcrConfig | None = None) -> OcrReader:
    """Factory for the configured OCR fallback."""
    config = config or OcrConfig()
    if config.engine == "paddle":
        return PaddleOcrReader(config)
    if config.engine == "tesseract":
        return TesseractOcrReader(config)
    return NoopOcrReader()


__all__ = ["OcrReader", "PaddleOcrReader", "TesseractOcrReader", "create_ocr_reader"]
